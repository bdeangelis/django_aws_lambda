from django.apps import AppConfig


class IngredientsConfig(AppConfig):
    name = 'ingredients'
